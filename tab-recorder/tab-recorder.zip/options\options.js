/**
 * Tab Recorder — Options Page Script
 * Handles loading, saving, and resetting all extension settings.
 */

const $ = (sel) => document.querySelector(sel);

// ── Default Settings ───────────────────────────────────
const DEFAULT_SETTINGS = {
  mode: 'tab',
  resolution: '1080p',
  fps: 30,
  bitrate: 8000000,
  codec: 'vp9',
  systemAudio: true,
  microphone: false,
  micDeviceId: 'default',
  countdown: 3,
  filenamePattern: 'Recording_{date}_{time}',
  openAfterSave: true,
  showNotifications: true,
  theme: 'dark',
  recordingCounter: 0,
};

// ── DOM Elements ───────────────────────────────────────
const optMode = $('#opt-mode');
const optResolution = $('#opt-resolution');
const optFps = $('#opt-fps');
const optBitrate = $('#opt-bitrate');
const optCodec = $('#opt-codec');
const optCountdown = $('#opt-countdown');
const optSystemAudio = $('#opt-system-audio');
const optMicrophone = $('#opt-microphone');
const optFilename = $('#opt-filename');
const optFilenamePreview = $('#opt-filename-preview');
const optOpenAfterSave = $('#opt-open-after-save');
const optNotifications = $('#opt-notifications');
const btnSave = $('#btn-save');
const btnReset = $('#btn-reset');
const saveStatus = $('#save-status');

// ── Init ───────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  loadSettings();
  setupListeners();
});

// ── Load Settings ──────────────────────────────────────
function loadSettings() {
  chrome.storage.local.get(DEFAULT_SETTINGS, (settings) => {
    optMode.value = settings.mode;
    optResolution.value = settings.resolution;
    optFps.value = String(settings.fps);
    optBitrate.value = String(settings.bitrate);
    optCodec.value = settings.codec;
    optCountdown.value = String(settings.countdown);
    optSystemAudio.checked = settings.systemAudio;
    optMicrophone.checked = settings.microphone;
    optFilename.value = settings.filenamePattern;
    optOpenAfterSave.checked = settings.openAfterSave;
    optNotifications.checked = settings.showNotifications;

    updateFilenamePreview();
  });
}

// ── Save Settings ──────────────────────────────────────
function saveSettings() {
  const settings = {
    mode: optMode.value,
    resolution: optResolution.value,
    fps: parseInt(optFps.value),
    bitrate: parseInt(optBitrate.value),
    codec: optCodec.value,
    countdown: parseInt(optCountdown.value),
    systemAudio: optSystemAudio.checked,
    microphone: optMicrophone.checked,
    filenamePattern: optFilename.value || 'Recording_{date}_{time}',
    openAfterSave: optOpenAfterSave.checked,
    showNotifications: optNotifications.checked,
  };

  chrome.storage.local.set(settings, () => {
    showSaveStatus();
  });
}

// ── Reset Settings ─────────────────────────────────────
function resetSettings() {
  chrome.storage.local.set(DEFAULT_SETTINGS, () => {
    loadSettings();
    showSaveStatus();
  });
}

// ── Event Listeners ────────────────────────────────────
function setupListeners() {
  btnSave.addEventListener('click', saveSettings);
  btnReset.addEventListener('click', () => {
    if (confirm('Reset all settings to defaults?')) {
      resetSettings();
    }
  });

  optFilename.addEventListener('input', updateFilenamePreview);
}

// ── Filename Preview ───────────────────────────────────
function updateFilenamePreview() {
  const pattern = optFilename.value || 'Recording_{date}_{time}';
  const now = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  const timeStr = `${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;

  const preview = pattern
    .replace(/\{date\}/gi, dateStr)
    .replace(/\{time\}/gi, timeStr)
    .replace(/\{counter\}/gi, '001')
    .replace(/\{mode\}/gi, optMode.value)
    .replace(/\{resolution\}/gi, optResolution.value);

  optFilenamePreview.textContent = `${preview}.webm`;
}

// ── Save Status Feedback ───────────────────────────────
let statusTimeout = null;

function showSaveStatus() {
  clearTimeout(statusTimeout);
  saveStatus.classList.remove('hidden');
  statusTimeout = setTimeout(() => {
    saveStatus.classList.add('hidden');
  }, 3000);
}
