/**
 * Tab Recorder — Offscreen Document Script
 * Hosts MediaRecorder + Web Audio API since service workers can't access DOM APIs.
 * Communicates with background.js via chrome.runtime messaging.
 */

// ── State ──────────────────────────────────────────────
let mediaRecorder = null;
let chunks = [];
let recordingState = 'inactive'; // 'inactive' | 'recording' | 'paused'
let startTime = 0;
let pausedDuration = 0;
let pauseStart = 0;
let timerInterval = null;
let mimeType = 'video/webm';

// Audio mixing
let audioContext = null;
let audioDestination = null;
let captureStream = null;
let micStream = null;
let combinedStream = null;

// ── Message Handler ────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target !== 'offscreen') return;

  switch (message.type) {
    case 'start-recording':
      handleStartRecording(message.data)
        .then(() => sendResponse({ success: true }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true; // async response

    case 'pause-recording':
      handlePause();
      sendResponse({ success: true });
      break;

    case 'resume-recording':
      handleResume();
      sendResponse({ success: true });
      break;

    case 'stop-recording':
      handleStopRecording()
        .then((result) => sendResponse({ success: true, ...result }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true; // async response

    case 'get-status':
      sendResponse({
        state: recordingState,
        elapsed: getElapsedSeconds(),
        size: getEstimatedSize(),
      });
      break;

    default:
      break;
  }
});

// ── Start Recording ────────────────────────────────────
async function handleStartRecording(config) {
  const {
    streamId,
    mode,
    systemAudio,
    microphone,
    micDeviceId,
    bitrate,
    codec,
    fps,
    resolution,
  } = config;

  try {
    // 1. Acquire the capture stream
    if (mode === 'tab') {
      // Tab capture — use the streamId from chrome.tabCapture
      const constraints = {
        audio: {
          mandatory: {
            chromeMediaSource: 'tab',
            chromeMediaSourceId: streamId,
          },
        },
        video: {
          mandatory: {
            chromeMediaSource: 'tab',
            chromeMediaSourceId: streamId,
            maxFrameRate: fps || 30,
          },
        },
      };
      captureStream = await navigator.mediaDevices.getUserMedia(constraints);
    } else {
      // Window or screen capture — use the desktopCapture streamId
      const constraints = {
        audio: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: streamId,
          },
        },
        video: {
          mandatory: {
            chromeMediaSource: 'desktop',
            chromeMediaSourceId: streamId,
            maxFrameRate: fps || 30,
          },
        },
      };

      try {
        captureStream = await navigator.mediaDevices.getUserMedia(constraints);
      } catch (audioErr) {
        // System audio might not be available for desktop capture
        // Retry without audio
        const videoOnlyConstraints = {
          video: {
            mandatory: {
              chromeMediaSource: 'desktop',
              chromeMediaSourceId: streamId,
              maxFrameRate: fps || 30,
            },
          },
        };
        captureStream = await navigator.mediaDevices.getUserMedia(videoOnlyConstraints);
      }
    }

    // 2. Build the audio mix
    const videoTracks = captureStream.getVideoTracks();
    let finalAudioStream = null;

    const hasSystemAudio = captureStream.getAudioTracks().length > 0 && systemAudio;
    const wantsMic = microphone;

    if (hasSystemAudio || wantsMic) {
      audioContext = new AudioContext();
      audioDestination = audioContext.createMediaStreamDestination();

      // Add system/tab audio
      if (hasSystemAudio) {
        const systemSource = audioContext.createMediaStreamSource(
          new MediaStream(captureStream.getAudioTracks())
        );
        const systemGain = audioContext.createGain();
        systemGain.gain.value = 1.0;
        systemSource.connect(systemGain);
        systemGain.connect(audioDestination);

        // Also route to speakers so user can hear tab audio
        if (mode === 'tab') {
          systemGain.connect(audioContext.destination);
        }
      }

      // Add microphone
      if (wantsMic) {
        try {
          micStream = await navigator.mediaDevices.getUserMedia({
            audio: {
              deviceId: micDeviceId && micDeviceId !== 'default'
                ? { exact: micDeviceId }
                : undefined,
              echoCancellation: true,
              noiseSuppression: true,
              autoGainControl: true,
            },
          });
          const micSource = audioContext.createMediaStreamSource(micStream);
          const micGain = audioContext.createGain();
          micGain.gain.value = 1.0;
          micSource.connect(micGain);
          micGain.connect(audioDestination);
        } catch (micErr) {
          console.warn('[Offscreen] Microphone not available:', micErr.message);
          // Continue without mic
        }
      }

      finalAudioStream = audioDestination.stream;
    }

    // 3. Combine video + mixed audio into final stream
    combinedStream = new MediaStream();

    // Add video tracks
    for (const track of videoTracks) {
      combinedStream.addTrack(track);
    }

    // Add mixed audio tracks
    if (finalAudioStream) {
      for (const track of finalAudioStream.getAudioTracks()) {
        combinedStream.addTrack(track);
      }
    }

    // 4. Configure and start MediaRecorder
    mimeType = negotiateCodec(codec || 'vp9');

    const recorderOptions = {
      mimeType,
      videoBitsPerSecond: bitrate || 8_000_000,
    };

    mediaRecorder = new MediaRecorder(combinedStream, recorderOptions);
    chunks = [];

    mediaRecorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) {
        chunks.push(e.data);
      }
    };

    mediaRecorder.onstop = () => {
      recordingState = 'inactive';
      clearInterval(timerInterval);
      broadcastState();
    };

    mediaRecorder.onerror = (event) => {
      console.error('[Offscreen] MediaRecorder error:', event.error);
      recordingState = 'inactive';
      clearInterval(timerInterval);
      broadcastState();
    };

    // Start recording with 1-second chunks
    mediaRecorder.start(1000);
    recordingState = 'recording';
    startTime = Date.now();
    pausedDuration = 0;
    pauseStart = 0;

    // Start timer broadcast
    timerInterval = setInterval(() => {
      broadcastState();
    }, 1000);

    broadcastState();
    console.log('[Offscreen] Recording started:', mimeType);

  } catch (err) {
    console.error('[Offscreen] Failed to start recording:', err);
    cleanup();
    throw err;
  }
}

// ── Pause ──────────────────────────────────────────────
function handlePause() {
  if (mediaRecorder && recordingState === 'recording') {
    mediaRecorder.pause();
    recordingState = 'paused';
    pauseStart = Date.now();
    broadcastState();
  }
}

// ── Resume ─────────────────────────────────────────────
function handleResume() {
  if (mediaRecorder && recordingState === 'paused') {
    mediaRecorder.resume();
    recordingState = 'recording';
    if (pauseStart) {
      pausedDuration += Date.now() - pauseStart;
      pauseStart = 0;
    }
    broadcastState();
  }
}

// ── Stop Recording ─────────────────────────────────────
async function handleStopRecording() {
  return new Promise((resolve, reject) => {
    if (!mediaRecorder || recordingState === 'inactive') {
      cleanup();
      resolve({ size: 0 });
      return;
    }

    // Account for final pause
    if (pauseStart) {
      pausedDuration += Date.now() - pauseStart;
      pauseStart = 0;
    }

    const originalOnStop = mediaRecorder.onstop;

    mediaRecorder.onstop = () => {
      recordingState = 'inactive';
      clearInterval(timerInterval);

      // Assemble blob
      const blob = new Blob(chunks, { type: mimeType });
      const blobUrl = URL.createObjectURL(blob);
      const size = blob.size;

      // Send blob URL to background for download
      chrome.runtime.sendMessage({
        target: 'background',
        type: 'recording-complete',
        data: {
          blobUrl,
          size,
          mimeType,
          duration: getElapsedSeconds(),
        },
      });

      cleanup();
      broadcastState();
      resolve({ size, blobUrl });
    };

    mediaRecorder.stop();
  });
}

// ── Helpers ────────────────────────────────────────────
function getElapsedSeconds() {
  if (startTime === 0) return 0;
  const now = Date.now();
  const currentPause = pauseStart ? (now - pauseStart) : 0;
  return Math.floor((now - startTime - pausedDuration - currentPause) / 1000);
}

function getEstimatedSize() {
  let total = 0;
  for (const chunk of chunks) total += chunk.size;
  return total;
}

function negotiateCodec(preferred) {
  const codecs = preferred === 'vp9'
    ? [
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp9',
        'video/webm;codecs=vp8,opus',
        'video/webm;codecs=vp8',
        'video/webm',
      ]
    : [
        'video/webm;codecs=vp8,opus',
        'video/webm;codecs=vp8',
        'video/webm;codecs=vp9,opus',
        'video/webm;codecs=vp9',
        'video/webm',
      ];

  for (const c of codecs) {
    if (MediaRecorder.isTypeSupported(c)) return c;
  }
  return 'video/webm';
}

function broadcastState() {
  chrome.runtime.sendMessage({
    target: 'background',
    type: 'recording-state',
    data: {
      state: recordingState,
      elapsed: getElapsedSeconds(),
      size: getEstimatedSize(),
    },
  }).catch(() => {
    // Background might not be listening yet
  });
}

function cleanup() {
  // Stop all tracks
  if (captureStream) {
    captureStream.getTracks().forEach(t => t.stop());
    captureStream = null;
  }
  if (micStream) {
    micStream.getTracks().forEach(t => t.stop());
    micStream = null;
  }
  if (combinedStream) {
    combinedStream = null;
  }

  // Close audio context
  if (audioContext && audioContext.state !== 'closed') {
    audioContext.close().catch(() => {});
    audioContext = null;
    audioDestination = null;
  }

  mediaRecorder = null;
  chunks = [];
  startTime = 0;
  pausedDuration = 0;
  pauseStart = 0;
  clearInterval(timerInterval);
}

// Keep offscreen document alive during recording
setInterval(() => {
  if (recordingState !== 'inactive') {
    // Heartbeat — prevents Chrome from killing the offscreen document
    chrome.runtime.sendMessage({ target: 'background', type: 'heartbeat' }).catch(() => {});
  }
}, 20000);
