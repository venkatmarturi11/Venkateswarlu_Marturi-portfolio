/**
 * Tab Recorder — Content Script Overlay
 * Injects a floating recording control bar into the page.
 * Uses Shadow DOM to avoid CSS conflicts.
 */

(function() {
  'use strict';

  // Prevent double injection
  if (document.getElementById('tab-recorder-overlay-host')) return;

  let overlayHost = null;
  let shadowRoot = null;
  let timerInterval = null;
  let isVisible = false;
  let isDragging = false;
  let dragOffset = { x: 0, y: 0 };
  let autoHideTimeout = null;

  // ── Listen for messages from background ──────────────
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.type) {
      case 'show-overlay':
        showOverlay(message.data?.state || 'recording');
        sendResponse({ success: true });
        break;

      case 'hide-overlay':
        hideOverlay();
        sendResponse({ success: true });
        break;

      case 'state-update':
        if (isVisible) {
          updateOverlay(message.data);
        }
        sendResponse({ success: true });
        break;
    }
  });

  // ── Create Overlay ───────────────────────────────────
  function showOverlay(state) {
    if (overlayHost) {
      updateOverlayState(state);
      return;
    }

    // Create host element
    overlayHost = document.createElement('div');
    overlayHost.id = 'tab-recorder-overlay-host';
    overlayHost.style.cssText = `
      position: fixed;
      top: 16px;
      left: 50%;
      transform: translateX(-50%);
      z-index: 2147483647;
      pointer-events: auto;
    `;

    // Attach shadow DOM
    shadowRoot = overlayHost.attachShadow({ mode: 'closed' });

    // Inject styles + HTML
    shadowRoot.innerHTML = `
      <style>
        :host {
          all: initial;
          font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        .overlay-bar {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 8px 16px;
          background: rgba(15, 15, 30, 0.92);
          backdrop-filter: blur(20px);
          -webkit-backdrop-filter: blur(20px);
          border: 1px solid rgba(139, 92, 246, 0.25);
          border-radius: 50px;
          box-shadow: 0 8px 32px rgba(0, 0, 0, 0.5), 0 0 16px rgba(139, 92, 246, 0.15);
          cursor: grab;
          user-select: none;
          transition: opacity 0.3s ease, transform 0.3s ease;
          opacity: 1;
          transform: translateY(0);
        }

        .overlay-bar.hiding {
          opacity: 0.15;
          transform: translateY(-4px);
        }

        .overlay-bar:hover {
          opacity: 1 !important;
          transform: translateY(0) !important;
        }

        .overlay-bar.dragging {
          cursor: grabbing;
          opacity: 1 !important;
        }

        .indicator {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #EF4444;
          animation: pulse 1.5s ease-in-out infinite;
        }

        .dot.paused {
          background: #F59E0B;
          animation: none;
        }

        @keyframes pulse {
          0%, 100% { opacity: 1; box-shadow: 0 0 4px rgba(239, 68, 68, 0.6); }
          50% { opacity: 0.4; box-shadow: 0 0 8px rgba(239, 68, 68, 0.3); }
        }

        .status-text {
          font-size: 11px;
          font-weight: 600;
          color: #EF4444;
          text-transform: uppercase;
          letter-spacing: 0.8px;
        }

        .status-text.paused {
          color: #F59E0B;
        }

        .divider {
          width: 1px;
          height: 20px;
          background: rgba(255, 255, 255, 0.12);
        }

        .timer {
          font-size: 14px;
          font-weight: 700;
          color: #e8e8f0;
          font-variant-numeric: tabular-nums;
          letter-spacing: 1px;
          min-width: 60px;
          text-align: center;
        }

        .btn {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 30px;
          height: 30px;
          border: none;
          border-radius: 50%;
          cursor: pointer;
          transition: all 0.2s ease;
          padding: 0;
        }

        .btn:hover {
          transform: scale(1.1);
        }

        .btn:active {
          transform: scale(0.95);
        }

        .btn-pause {
          background: rgba(245, 158, 11, 0.15);
          color: #F59E0B;
        }

        .btn-pause:hover {
          background: rgba(245, 158, 11, 0.25);
        }

        .btn-resume {
          background: rgba(16, 185, 129, 0.15);
          color: #10B981;
        }

        .btn-resume:hover {
          background: rgba(16, 185, 129, 0.25);
        }

        .btn-stop {
          background: rgba(239, 68, 68, 0.15);
          color: #EF4444;
        }

        .btn-stop:hover {
          background: rgba(239, 68, 68, 0.25);
        }

        .hidden {
          display: none !important;
        }

        svg {
          pointer-events: none;
        }
      </style>

      <div class="overlay-bar" id="overlay-bar">
        <div class="indicator">
          <span class="dot" id="dot"></span>
          <span class="status-text" id="status-text">REC</span>
        </div>
        <div class="divider"></div>
        <span class="timer" id="timer">00:00</span>
        <div class="divider"></div>
        <button class="btn btn-pause" id="btn-pause" title="Pause">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <rect x="6" y="4" width="4" height="16" rx="1"/>
            <rect x="14" y="4" width="4" height="16" rx="1"/>
          </svg>
        </button>
        <button class="btn btn-resume hidden" id="btn-resume" title="Resume">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
            <polygon points="5,3 19,12 5,21"/>
          </svg>
        </button>
        <button class="btn btn-stop" id="btn-stop" title="Stop Recording">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
            <rect x="4" y="4" width="16" height="16" rx="2"/>
          </svg>
        </button>
      </div>
    `;

    document.body.appendChild(overlayHost);
    isVisible = true;

    // Setup interactions
    const bar = shadowRoot.getElementById('overlay-bar');
    const btnPause = shadowRoot.getElementById('btn-pause');
    const btnResume = shadowRoot.getElementById('btn-resume');
    const btnStop = shadowRoot.getElementById('btn-stop');

    // Drag handling
    bar.addEventListener('mousedown', (e) => {
      if (e.target.closest('.btn')) return;
      isDragging = true;
      bar.classList.add('dragging');
      const rect = overlayHost.getBoundingClientRect();
      dragOffset.x = e.clientX - rect.left;
      dragOffset.y = e.clientY - rect.top;
      overlayHost.style.transform = 'none';
      e.preventDefault();
    });

    document.addEventListener('mousemove', (e) => {
      if (!isDragging) return;
      const x = Math.max(0, Math.min(window.innerWidth - 200, e.clientX - dragOffset.x));
      const y = Math.max(0, Math.min(window.innerHeight - 50, e.clientY - dragOffset.y));
      overlayHost.style.left = x + 'px';
      overlayHost.style.top = y + 'px';
    });

    document.addEventListener('mouseup', () => {
      if (isDragging) {
        isDragging = false;
        bar.classList.remove('dragging');
        startAutoHide();
      }
    });

    // Control buttons
    btnPause.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.runtime.sendMessage({ type: 'pause-recording' });
    });

    btnResume.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.runtime.sendMessage({ type: 'resume-recording' });
    });

    btnStop.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.runtime.sendMessage({ type: 'stop-recording' });
    });

    // Auto-hide behavior
    bar.addEventListener('mouseenter', () => {
      clearTimeout(autoHideTimeout);
      bar.classList.remove('hiding');
    });

    bar.addEventListener('mouseleave', () => {
      startAutoHide();
    });

    updateOverlayState(state);
    startAutoHide();
  }

  // ── Update Overlay ───────────────────────────────────
  function updateOverlay(data) {
    if (!shadowRoot) return;

    if (data.state === 'inactive') {
      hideOverlay();
      return;
    }

    updateOverlayState(data.state);

    const timer = shadowRoot.getElementById('timer');
    if (timer && data.elapsed !== undefined) {
      timer.textContent = formatTime(data.elapsed);
    }
  }

  function updateOverlayState(state) {
    if (!shadowRoot) return;

    const dot = shadowRoot.getElementById('dot');
    const statusText = shadowRoot.getElementById('status-text');
    const btnPause = shadowRoot.getElementById('btn-pause');
    const btnResume = shadowRoot.getElementById('btn-resume');

    if (state === 'paused') {
      dot.classList.add('paused');
      statusText.classList.add('paused');
      statusText.textContent = 'PAUSED';
      btnPause.classList.add('hidden');
      btnResume.classList.remove('hidden');
    } else {
      dot.classList.remove('paused');
      statusText.classList.remove('paused');
      statusText.textContent = 'REC';
      btnPause.classList.remove('hidden');
      btnResume.classList.add('hidden');
    }
  }

  // ── Hide Overlay ─────────────────────────────────────
  function hideOverlay() {
    clearTimeout(autoHideTimeout);
    clearInterval(timerInterval);

    if (overlayHost && overlayHost.parentNode) {
      overlayHost.parentNode.removeChild(overlayHost);
    }

    overlayHost = null;
    shadowRoot = null;
    isVisible = false;
  }

  // ── Auto-hide ────────────────────────────────────────
  function startAutoHide() {
    clearTimeout(autoHideTimeout);
    autoHideTimeout = setTimeout(() => {
      if (shadowRoot && !isDragging) {
        const bar = shadowRoot.getElementById('overlay-bar');
        if (bar) bar.classList.add('hiding');
      }
    }, 3000);
  }

  // ── Helpers ──────────────────────────────────────────
  function formatTime(totalSeconds) {
    const mins = Math.floor(totalSeconds / 60);
    const secs = Math.floor(totalSeconds % 60);
    if (totalSeconds >= 3600) {
      const hrs = Math.floor(totalSeconds / 3600);
      return `${hrs}:${String(mins % 60).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  }
})();
