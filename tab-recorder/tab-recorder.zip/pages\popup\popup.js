/**
 * Screen Recorder for Google Chrome™ - UI Logic
 */

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// ── DOM Elements ───────────────────────────────────────
const setupView = $('#setup-view');
const playerView = $('#player-view');

// Form controls
const selectMode = $('#select-mode');
const chkSystemAudio = $('#chk-system-audio');
const chkMicrophone = $('#chk-microphone');
const micSelectContainer = $('#mic-select-container');
const selectMic = $('#select-mic');
const selectFormat = $('#select-format');
const selectResolution = $('#select-resolution');
const selectFps = $('#select-fps');
const selectCountdown = $('#select-countdown');
const selectBitrate = $('#select-bitrate');
const inputFilename = $('#input-filename');

// Collapsible
const btnAdvanced = $('#btn-advanced');
const advancedContent = $('#advanced-content');

// Action buttons
const btnStart = $('#btn-start');
const btnStop = $('#btn-stop');
const btnSave = $('#btn-save');
const btnNew = $('#btn-new');

// Status and Video
const statusMsg = $('#recording-status-msg');
const errorMsg = $('#error-msg');
const videoPreview = $('#video-preview');

// ── Default Settings ───────────────────────────────────
const DEFAULT_SETTINGS = {
  mode: 'screen',
  systemAudio: true,
  microphone: false,
  micDeviceId: 'default',
  format: 'vp9',
  resolution: '1080p',
  fps: 30,
  countdown: 0,
  bitrate: 8000000,
  filenamePattern: 'Recording_{date}_{time}'
};

// ── State ──────────────────────────────────────────────
let isRecording = false;

// ── Init ───────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadSettings();
  setupEventListeners();
  enumerateMicrophones();
  checkCurrentState();
});

// ── Load Settings ──────────────────────────────────────
async function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(DEFAULT_SETTINGS, (settings) => {
      selectMode.value = settings.mode;
      chkSystemAudio.checked = settings.systemAudio;
      chkMicrophone.checked = settings.microphone;
      
      micSelectContainer.classList.toggle('hidden', !settings.microphone);
      
      selectFormat.value = settings.format;
      selectResolution.value = settings.resolution;
      selectFps.value = String(settings.fps);
      selectCountdown.value = String(settings.countdown);
      selectBitrate.value = String(settings.bitrate);
      inputFilename.value = settings.filenamePattern;
      resolve();
    });
  });
}

// ── Save Settings ──────────────────────────────────────
function saveSettings() {
  const settings = {
    mode: selectMode.value,
    systemAudio: chkSystemAudio.checked,
    microphone: chkMicrophone.checked,
    micDeviceId: selectMic.value,
    format: selectFormat.value,
    resolution: selectResolution.value,
    fps: parseInt(selectFps.value),
    countdown: parseInt(selectCountdown.value),
    bitrate: parseInt(selectBitrate.value),
    filenamePattern: inputFilename.value
  };
  chrome.storage.local.set(settings);
  return settings;
}

// ── Check Current State ────────────────────────────────
function checkCurrentState() {
  chrome.runtime.sendMessage({ type: 'get-recording-state' }, (response) => {
    if (chrome.runtime.lastError || !response) return;

    if (response.state === 'recording' || response.state === 'paused') {
      showRecordingState();
    } else if (response.state === 'inactive' && response.lastRecording) {
      showPlayerView(response.lastRecording.blobUrl);
    } else {
      showSetupView();
    }
  });
}

// ── Event Listeners ────────────────────────────────────
function setupEventListeners() {
  // Save settings on any change
  [selectMode, chkSystemAudio, chkMicrophone, selectMic, selectFormat, 
   selectResolution, selectFps, selectCountdown, selectBitrate, inputFilename].forEach(el => {
    el.addEventListener('change', () => {
      if (el === chkMicrophone) {
        micSelectContainer.classList.toggle('hidden', !chkMicrophone.checked);
        if (chkMicrophone.checked) enumerateMicrophones();
      }
      saveSettings();
    });
  });

  // Collapsible Advanced Options
  btnAdvanced.addEventListener('click', () => {
    const isExpanded = btnAdvanced.parentElement.classList.toggle('open');
    advancedContent.style.display = isExpanded ? 'grid' : 'none';
  });

  // Start Recording
  btnStart.addEventListener('click', handleStart);

  // Stop Recording
  btnStop.addEventListener('click', handleStop);

  // Save to Computer
  btnSave.addEventListener('click', handleSave);

  // New Recording
  btnNew.addEventListener('click', showSetupView);

  // Background Messages
  chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'recording-finished' && message.data) {
      showPlayerView(message.data.blobUrl);
    } else if (message.type === 'state-update') {
      if (message.data.state === 'recording' || message.data.state === 'paused') {
        showRecordingState();
      }
    }
  });
}

// ── Start Recording ────────────────────────────────────
async function handleStart() {
  hideError();
  const settings = saveSettings();
  btnStart.disabled = true;

  try {
    if (settings.countdown > 0) {
      btnStart.innerHTML = `Starting in ${settings.countdown}...`;
      await new Promise(r => setTimeout(r, settings.countdown * 1000));
    }

    const res = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { type: 'start-recording', data: settings },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (!response || !response.success) {
            reject(new Error(response?.error || 'Failed to start'));
            return;
          }
          resolve(response);
        }
      );
    });

    showRecordingState();

  } catch (err) {
    showError(err.message);
    btnStart.disabled = false;
    btnStart.innerHTML = `
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14z"/><path d="M8 15h8V9H8v6z"/></svg>
      Capture Screen
    `;
  }
}

// ── Stop Recording ─────────────────────────────────────
function handleStop() {
  btnStop.disabled = true;
  chrome.runtime.sendMessage({ type: 'stop-recording' });
}

// ── Save Recording ─────────────────────────────────────
function handleSave() {
  btnSave.disabled = true;
  btnSave.textContent = 'Saving...';
  
  chrome.runtime.sendMessage({ type: 'save-recording' }, (res) => {
    btnSave.disabled = false;
    btnSave.innerHTML = `
      <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/></svg>
      Save to your computer
    `;
    if (chrome.runtime.lastError || (res && !res.success)) {
      alert('Error saving file: ' + (res?.error || chrome.runtime.lastError?.message));
    }
  });
}

// ── View Management ────────────────────────────────────
function showSetupView() {
  isRecording = false;
  setupView.classList.remove('hidden');
  playerView.classList.add('hidden');
  
  btnStart.disabled = false;
  btnStop.disabled = true;
  statusMsg.classList.add('hidden');
  
  btnStart.innerHTML = `
    <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor"><path d="M21 3H3c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H3V5h18v14z"/><path d="M8 15h8V9H8v6z"/></svg>
    Capture Screen
  `;
}

function showRecordingState() {
  isRecording = true;
  setupView.classList.remove('hidden');
  playerView.classList.add('hidden');
  
  btnStart.disabled = true;
  btnStop.disabled = false;
  statusMsg.classList.remove('hidden');
  hideError();
  
  btnStart.textContent = 'Recording...';
}

function showPlayerView(blobUrl) {
  isRecording = false;
  setupView.classList.add('hidden');
  playerView.classList.remove('hidden');
  
  videoPreview.src = blobUrl;
  videoPreview.load();
}

function showError(msg) {
  let text = msg;
  if (msg.includes('cancel')) text = 'Screen selection was cancelled.';
  if (msg.includes('permission')) text = 'Permission denied.';
  
  errorMsg.textContent = text;
  errorMsg.classList.remove('hidden');
}

function hideError() {
  errorMsg.classList.add('hidden');
}

// ── Microphone Enumeration ─────────────────────────────
async function enumerateMicrophones() {
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const mics = devices.filter((d) => d.kind === 'audioinput');

    selectMic.innerHTML = '';
    mics.forEach((mic, i) => {
      const option = document.createElement('option');
      option.value = mic.deviceId;
      option.textContent = mic.label || `Microphone ${i + 1}`;
      selectMic.appendChild(option);
    });

    chrome.storage.local.get({ micDeviceId: 'default' }, (s) => {
      if (s.micDeviceId && [...selectMic.options].some((o) => o.value === s.micDeviceId)) {
        selectMic.value = s.micDeviceId;
      }
    });
  } catch (err) {
    console.warn('Could not enumerate mics:', err);
  }
}
