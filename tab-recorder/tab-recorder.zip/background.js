/**
 * Tab Recorder — Background Service Worker
 * Orchestrates recording: manages offscreen document, tab/desktop capture,
 * message routing, and download handling.
 */

// ── State ──────────────────────────────────────────────
let recordingState = 'inactive'; // 'inactive' | 'countdown' | 'recording' | 'paused'
let recordingTabId = null;
let currentConfig = null;
let recordingInfo = { elapsed: 0, size: 0 };
let lastRecording = null;

// ── Defaults ───────────────────────────────────────────
const DEFAULT_SETTINGS = {
  mode: 'tab',
  resolution: '1080p',
  fps: 30,
  bitrate: 8000000,
  codec: 'vp9',
  systemAudio: true,
  microphone: false,
  micDeviceId: 'default',
  countdown: 3,
  filenamePattern: 'Recording_{date}_{time}',
  openAfterSave: true,
  showNotifications: true,
  theme: 'dark',
  recordingCounter: 0,
};

// ── Message Handler ────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Route messages intended for offscreen document
  if (message.target === 'offscreen') return false;

  // Handle messages for background
  if (message.target === 'background') {
    switch (message.type) {
      case 'recording-state':
        handleRecordingStateUpdate(message.data);
        sendResponse({ success: true });
        break;

      case 'recording-complete':
        handleRecordingComplete(message.data);
        sendResponse({ success: true });
        break;

      case 'heartbeat':
        sendResponse({ success: true });
        break;

      default:
        break;
    }
    return false;
  }

  // Handle commands from popup / content scripts
  switch (message.type) {
    case 'start-recording':
      startRecording(message.data)
        .then(() => sendResponse({ success: true }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true; // async

    case 'pause-recording':
      forwardToOffscreen('pause-recording');
      recordingState = 'paused';
      broadcastToAll();
      sendResponse({ success: true });
      break;

    case 'resume-recording':
      forwardToOffscreen('resume-recording');
      recordingState = 'recording';
      broadcastToAll();
      sendResponse({ success: true });
      break;

    case 'stop-recording':
      forwardToOffscreen('stop-recording')
        .then(() => sendResponse({ success: true }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true; // async

    case 'get-recording-state':
      sendResponse({
        state: recordingState,
        elapsed: recordingInfo.elapsed,
        size: recordingInfo.size,
        config: currentConfig,
        lastRecording: lastRecording,
      });
      break;

    case 'save-recording':
      handleSaveRecording()
        .then(() => sendResponse({ success: true }))
        .catch((err) => sendResponse({ success: false, error: err.message }));
      return true;

    default:
      break;
  }
});

// ── Start Recording Flow ───────────────────────────────
async function startRecording(config) {
  currentConfig = config;
  const { mode } = config;

  let streamId;

  if (mode === 'tab') {
    // Tab capture: get stream ID from current tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) throw new Error('No active tab found');

    recordingTabId = tab.id;
    streamId = await getTabStreamId(tab.id);

  } else {
    // Window or screen capture: use desktopCapture picker
    const sources = mode === 'window' ? ['window'] : ['screen'];
    streamId = await chooseDesktopMedia(sources);
  }

  if (!streamId) {
    throw new Error('No stream ID obtained. User may have cancelled.');
  }

  // Ensure offscreen document exists
  await ensureOffscreenDocument();

  // Send start command to offscreen
  await chrome.runtime.sendMessage({
    target: 'offscreen',
    type: 'start-recording',
    data: {
      streamId,
      mode,
      systemAudio: config.systemAudio,
      microphone: config.microphone,
      micDeviceId: config.micDeviceId,
      bitrate: config.bitrate,
      codec: config.codec,
      fps: config.fps,
      resolution: config.resolution,
    },
  });

  recordingState = 'recording';
  recordingInfo = { elapsed: 0, size: 0 };
  broadcastToAll();

  // Show notification
  if (config.showNotifications !== false) {
    showNotification('Recording Started', `Recording ${mode} in ${config.resolution} at ${config.fps} FPS`);
  }

  // Inject content overlay into the recorded tab
  if (recordingTabId) {
    try {
      await chrome.tabs.sendMessage(recordingTabId, {
        type: 'show-overlay',
        data: { state: 'recording' },
      });
    } catch (_) {
      // Content script not loaded yet — inject programmatically
      try {
        await chrome.scripting.executeScript({
          target: { tabId: recordingTabId },
          files: ['content/overlay.js'],
        });
        await chrome.scripting.insertCSS({
          target: { tabId: recordingTabId },
          files: ['content/overlay.css'],
        });
        // Retry the message after injection
        setTimeout(() => {
          chrome.tabs.sendMessage(recordingTabId, {
            type: 'show-overlay',
            data: { state: 'recording' },
          }).catch(() => {});
        }, 200);
      } catch (injectErr) {
        console.warn('[Background] Could not inject overlay:', injectErr.message);
      }
    }
  }
}

// ── Tab Capture ────────────────────────────────────────
function getTabStreamId(tabId) {
  return new Promise((resolve, reject) => {
    chrome.tabCapture.getMediaStreamId(
      { targetTabId: tabId },
      (streamId) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(streamId);
      }
    );
  });
}

// ── Desktop Capture ────────────────────────────────────
function chooseDesktopMedia(sources) {
  return new Promise((resolve, reject) => {
    chrome.desktopCapture.chooseDesktopMedia(
      sources,
      (streamId, options) => {
        if (!streamId) {
          reject(new Error('User cancelled the screen selection'));
          return;
        }
        resolve(streamId);
      }
    );
  });
}

// ── Offscreen Document Management ──────────────────────
async function ensureOffscreenDocument() {
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
    documentUrls: [chrome.runtime.getURL('offscreen.html')],
  });

  if (existingContexts.length > 0) return;

  await chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['USER_MEDIA'],
    justification: 'Recording tab/screen content with MediaRecorder',
  });
}

async function closeOffscreenDocument() {
  try {
    const existingContexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
    });
    if (existingContexts.length > 0) {
      await chrome.offscreen.closeDocument();
    }
  } catch (_) {
    // Already closed
  }
}

// ── Forward messages to offscreen ──────────────────────
async function forwardToOffscreen(type, data = {}) {
  return chrome.runtime.sendMessage({
    target: 'offscreen',
    type,
    data,
  });
}

// ── Handle state updates from offscreen ────────────────
function handleRecordingStateUpdate(data) {
  recordingInfo.elapsed = data.elapsed || 0;
  recordingInfo.size = data.size || 0;

  if (data.state === 'paused') {
    recordingState = 'paused';
  } else if (data.state === 'recording') {
    recordingState = 'recording';
  } else if (data.state === 'inactive') {
    recordingState = 'inactive';
  }

  broadcastToAll();
}

// ── Handle recording complete ──────────────────────────
async function handleRecordingComplete(data) {
  const { blobUrl, size, mimeType, duration } = data;

  recordingState = 'inactive';
  lastRecording = { blobUrl, size, mimeType };
  
  broadcastToAll();
  
  // Also notify the UI that the recording is finished and ready for preview
  chrome.runtime.sendMessage({
    type: 'recording-finished',
    data: lastRecording
  }).catch(() => {});

  // Remove overlay from tab
  if (recordingTabId) {
    try {
      await chrome.tabs.sendMessage(recordingTabId, { type: 'hide-overlay' });
    } catch (_) { /* tab might be closed */ }
  }

  recordingTabId = null;
  currentConfig = null;
  recordingInfo = { elapsed: 0, size: 0 };
}

// ── Save Recording ─────────────────────────────────────
async function handleSaveRecording() {
  if (!lastRecording) throw new Error('No recording available to save');
  
  const { blobUrl, size } = lastRecording;
  const settings = await getSettings();
  const counter = (settings.recordingCounter || 0) + 1;

  const filename = generateFilenameFromPattern(settings.filenamePattern || 'Recording_{date}_{time}', {
    counter,
    mode: 'screen',
    resolution: '1080p',
  });

  await chrome.storage.local.set({ recordingCounter: counter });

  return new Promise((resolve, reject) => {
    chrome.downloads.download(
      {
        url: blobUrl,
        filename: `${filename}.webm`,
        saveAs: false,
      },
      (downloadId) => {
        if (chrome.runtime.lastError) {
          console.error('[Background] Download error:', chrome.runtime.lastError.message);
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }

        if (settings.openAfterSave && downloadId) {
          const listener = (delta) => {
            if (delta.id === downloadId && delta.state?.current === 'complete') {
              chrome.downloads.onChanged.removeListener(listener);
              chrome.downloads.show(downloadId);
            }
          };
          chrome.downloads.onChanged.addListener(listener);
        }

        resolve(downloadId);
      }
    );
  });
}

// ── Broadcast state to popup + content scripts ─────────
function broadcastToAll() {
  const stateMsg = {
    type: 'state-update',
    data: {
      state: recordingState,
      elapsed: recordingInfo.elapsed,
      size: recordingInfo.size,
    },
  };

  // Send to popup (if open)
  chrome.runtime.sendMessage(stateMsg).catch(() => {});

  // Send to content script overlay
  if (recordingTabId) {
    chrome.tabs.sendMessage(recordingTabId, stateMsg).catch(() => {});
  }
}

// ── Helpers ────────────────────────────────────────────
function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(DEFAULT_SETTINGS, resolve);
  });
}

function generateFilenameFromPattern(pattern, context = {}) {
  const now = new Date();
  const pad = (n, len = 2) => String(n).padStart(len, '0');
  const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  const timeStr = `${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;

  return pattern
    .replace(/\{date\}/gi, dateStr)
    .replace(/\{time\}/gi, timeStr)
    .replace(/\{counter\}/gi, pad(context.counter || 1, 3))
    .replace(/\{mode\}/gi, context.mode || 'tab')
    .replace(/\{resolution\}/gi, context.resolution || '1080p')
    .replace(/[<>:"/\\|?*]/g, '_');
}

function formatSize(bytes) {
  if (bytes === 0) return '0 B';
  const units = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${units[i]}`;
}

function showNotification(title, message) {
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title,
    message,
    silent: false,
  });
}

// ── Tab close listener ─────────────────────────────────
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === recordingTabId && recordingState !== 'inactive') {
    // Target tab was closed — stop recording
    forwardToOffscreen('stop-recording').catch(() => {});
  }
});

// ── Extension install ──────────────────────────────────
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // Set default settings on first install
    chrome.storage.local.set(DEFAULT_SETTINGS);
  }
});

// ── Extension icon click ───────────────────────────────
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({ url: chrome.runtime.getURL('pages/popup/popup.html') });
});
