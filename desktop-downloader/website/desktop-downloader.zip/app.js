function parseDurationToSeconds(duration) {
    const parts = duration.split(":");
    let secs = 0;
    try {
        if (parts.length === 3) {
            secs += parseInt(parts[0]) * 3600;
            secs += parseInt(parts[1]) * 60;
            secs += parseInt(parts[2]);
        } else if (parts.length === 2) {
            secs += parseInt(parts[0]) * 60;
            secs += parseInt(parts[1]);
        }
    } catch (e) {}
    return secs > 0 ? secs : 300;
}

function formatSeconds(totalSeconds) {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    if (hours > 0) {
        return `${hours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    } else {
        return `${minutes}:${String(seconds).padStart(2, '0')}`;
    }
}

function showError(msg) {
    const errDiv = document.getElementById('inline-error');
    if (errDiv) {
        errDiv.innerText = msg;
        errDiv.style.display = 'block';
        setTimeout(() => { errDiv.style.display = 'none'; }, 6000);
    } else {
        alert(msg);
    }
}

async function parseYoutubePlaylist(url) {
    try {
        const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
        const response = await fetch(proxyUrl);
        if (!response.ok) throw new Error("CORS Proxy down");
        
        const data = await response.json();
        const html = data.contents;
        
        const regex = /ytInitialData\s*=\s*({.*?});/s;
        const match = html.match(regex);
        if (match) {
            const json = JSON.parse(match[1]);
            let playlistTitle = "YouTube Playlist";
            let playlistDesc = "Imported YouTube Playlist";
            
            try {
                playlistTitle = json.header.playlistHeaderRenderer.title.runs[0].text;
                playlistDesc = json.header.playlistHeaderRenderer.descriptionText.runs[0].text || "";
            } catch (e) {}
            
            const tracks = [];
            try {
                const playlistVideoListRenderer = json.contents.twoColumnBrowseResultsRenderer.tabs[0].tabRenderer.content.sectionListRenderer.contents[0].itemSectionRenderer.contents[0].playlistVideoListRenderer;
                const playlistVideos = playlistVideoListRenderer.contents;
                
                playlistVideos.forEach((item, index) => {
                    const videoObj = item.playlistVideoRenderer;
                    if (videoObj) {
                        const title = videoObj.title.runs[0].text;
                        const duration = videoObj.lengthText ? videoObj.lengthText.simpleText : "5:00";
                        const sizeBytes = parseDurationToSeconds(duration) * 250000;
                        
                        tracks.push({
                            id: `yt-track-${index}`,
                            title: title,
                            duration: duration,
                            sizeBytes: sizeBytes,
                            isSelected: true,
                            status: 'PENDING',
                            progress: 0,
                            downloadUrl: "https://www.w3schools.com/html/mov_bbb.mp4"
                        });
                    }
                });
            } catch (e) {
                console.error("Error parsing videos list", e);
            }
            
            if (tracks.length > 0) {
                return {
                    title: playlistTitle,
                    description: playlistDesc,
                    tracks: tracks
                };
            }
        }
    } catch (e) {
        console.error("Dynamic YouTube playlist parser error: ", e);
    }
    return null;
}

async function parseM3UPlaylist(url) {
    try {
        const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
        const response = await fetch(proxyUrl);
        if (!response.ok) throw new Error("CORS Proxy down");
        
        const data = await response.json();
        const content = data.contents;
        
        const lines = content.split('\n');
        const tracks = [];
        let currentTitle = "";
        let currentDuration = "0:00";
        
        lines.forEach((rawLine, index) => {
            const line = rawLine.trim();
            if (line.startsWith('#EXTINF:')) {
                const parts = line.substring(8).split(',');
                if (parts.length > 0) {
                    const sec = parseInt(parts[0].trim()) || 0;
                    currentDuration = formatSeconds(sec);
                    currentTitle = parts.slice(1).join(',');
                }
            } else if (line.length > 0 && !line.startsWith('#')) {
                let title = currentTitle || line.substring(line.lastIndexOf('/') + 1).split('?')[0];
                title = title.replace(/\.[^/.]+$/, "");
                tracks.push({
                    id: `m3u-track-${index}`,
                    title: title,
                    duration: currentDuration,
                    sizeBytes: 8000000,
                    isSelected: true,
                    status: 'PENDING',
                    progress: 0,
                    downloadUrl: line.startsWith('http') ? line : new URL(line, url).toString()
                });
                currentTitle = "";
                currentDuration = "0:00";
            }
        });
        
        if (tracks.length > 0) {
            return {
                title: "M3U Playlist",
                description: "Successfully parsed M3U media list.",
                tracks: tracks
            };
        }
    } catch (e) {
        console.error("M3U parser error: ", e);
    }
    return null;
}

async function parseYoutubeVideo(url) {
    try {
        const proxyUrl = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
        const response = await fetch(proxyUrl);
        if (!response.ok) throw new Error("CORS Proxy down");
        const data = await response.json();
        const html = data.contents;
        
        const titleMatch = html.match(/<title>(.*?)<\/title>/);
        const title = titleMatch ? titleMatch[1].replace(" - YouTube", "") : "YouTube Video";
        
        return {
            title: "Direct Video Link",
            description: "Single YouTube Video download.",
            tracks: [{
                id: "yt-single-1",
                title: title,
                duration: "Unknown",
                sizeBytes: 15000000,
                isSelected: true,
                status: 'PENDING',
                progress: 0,
                downloadUrl: "https://www.w3schools.com/html/mov_bbb.mp4"
            }]
        };
    } catch (e) {
        console.error("Failed to parse YouTube video details", e);
    }
    return null;
}

function generateSingleTrackPlaylist(url) {
    let title = url.substring(url.lastIndexOf('/') + 1).split('?')[0];
    title = title.replace(/\.[^/.]+$/, "");
    if (!title || title.trim() === "") {
        title = "Direct Stream Download";
    }
    const isAudio = url.includes(".mp3") || url.includes(".m4a");
    
    return {
        title: "Direct Media Link",
        description: "Single direct URL download.",
        tracks: [{
            id: "direct-track-1",
            title: title,
            duration: "Unknown",
            sizeBytes: 12000000,
            isSelected: true,
            status: 'PENDING',
            progress: 0,
            downloadUrl: url
        }]
    };
}

// Simulated Tracks Data Generator
function generateSimulatedPlaylist() {
    const tracks = [];
    const baseTitle = "ORACLE SQL & PL/SQL - 9:00 AM IST by Mr. Sudhakar";
    
    for (let day = 9; day <= 68; day++) {
        if (day === 12) {
            tracks.push({
                id: `track-${day}-p1`,
                title: `Day 12 #PART 1 - ${baseTitle}`,
                duration: "1:15:30",
                sizeBytes: 209900000,
                isSelected: true,
                status: 'PENDING', // PENDING, QUEUED, DOWNLOADING, COMPLETED, FAILED
                progress: 0,
                downloadUrl: "https://www.w3schools.com/html/mov_bbb.mp4"
            });
            tracks.push({
                id: `track-${day}-p2`,
                title: `Day 12 #PART 2 - ${baseTitle}`,
                duration: "1:08:45",
                sizeBytes: 184700000,
                isSelected: true,
                status: 'PENDING',
                progress: 0,
                downloadUrl: "https://www.w3schools.com/html/mov_bbb.mp4"
            });
        } else {
            let sizeBytes = 150000000 + Math.floor(Math.random() * 90000000);
            let duration = `1:1${Math.floor(Math.random() * 9)}:${Math.floor(Math.random()*5)}${Math.floor(Math.random()*9)}`;
            if (day === 9) {
                sizeBytes = 156300000;
                duration = "1:02:15";
            } else if (day === 10) {
                sizeBytes = 200800000;
                duration = "1:18:40";
            } else if (day === 11) {
                sizeBytes = 199500000;
                duration = "1:16:10";
            }
            
            tracks.push({
                id: `track-${day}`,
                title: `Day ${day} - ${baseTitle}`,
                duration: duration,
                sizeBytes: sizeBytes,
                isSelected: true,
                status: 'PENDING',
                progress: 0,
                downloadUrl: "https://www.w3schools.com/html/mov_bbb.mp4"
            });
        }
    }
    return tracks;
}

let tracksList = [];
let isDownloading = false;
let isPaused = false;
let activeWorkers = [];
let downloadSubtitles = true;

// DOM Elements
const elInputSection = document.getElementById('input-section');
const elPlaylistDetails = document.getElementById('layout-playlist-details');
const elPbLoading = document.getElementById('pb-loading');
const elRvTracks = document.getElementById('rv-tracks');
const elHeaderTitle = document.getElementById('header-title');
const elBtnBack = document.getElementById('btn-back');
const elBtnShowDownloads = document.getElementById('btn-show-downloads');
const elCardSelectBar = document.getElementById('card-select-bar');
const elCardOverallProgress = document.getElementById('card-overall-progress');
const elDialogOptions = document.getElementById('dialog-options');
const elSwitchSubtitles = document.getElementById('switch-dialog-subtitles');
const elListControls = document.getElementById('layout-list-controls');
const elCbSelectAll = document.getElementById('cb-select-all');
const elFloatingDownloads = document.getElementById('floating-downloads');
const elBtnMinimizeDownloads = document.getElementById('btn-minimize-downloads');
const elActiveDownloadsList = document.getElementById('active-downloads-list');
const elBtnFloatingPause = document.getElementById('btn-floating-pause');
const elBtnFloatingCancel = document.getElementById('btn-floating-cancel');
const elFloatingContentArea = document.getElementById('floating-content-area');

if (elBtnMinimizeDownloads) {
    elBtnMinimizeDownloads.addEventListener('click', () => {
        if (elFloatingContentArea.style.display === 'none') {
            elFloatingContentArea.style.display = 'block';
            elBtnMinimizeDownloads.innerText = '_';
        } else {
            elFloatingContentArea.style.display = 'none';
            elBtnMinimizeDownloads.innerText = '□';
        }
    });
}

// Paste clipboard via Standard Web API with Backend Fallback
document.getElementById('btn-paste').addEventListener('click', async () => {
    let text = "";
    try {
        if (navigator.clipboard && navigator.clipboard.readText) {
            text = await navigator.clipboard.readText();
        }
    } catch (e) {
        console.warn("Browser clipboard API blocked/failed. Trying backend API...", e);
    }
    
    // Fallback to our python backend api
    if (!text) {
        try {
            const res = await fetch('/api/clipboard');
            if (res.ok) {
                const data = await res.json();
                text = data.text || "";
            }
        } catch (err) {
            console.error("Backend clipboard fallback failed:", err);
        }
    }

    if (text) {
        const input = document.getElementById('et-playlist-url');
        input.value = text;
        input.focus();
    } else {
        showError("Your clipboard is empty or the browser blocked pasting.");
    }

});

// Back Button Navigation
elBtnBack.addEventListener('click', () => {
    elInputSection.style.display = 'flex';
    elPlaylistDetails.style.display = 'none';
    elCardSelectBar.style.display = 'none';
    elCardOverallProgress.style.display = 'none';
    elBtnBack.style.display = 'none';
    elHeaderTitle.innerText = "Video Downloader";
});

async function parsePlaylistOnServer(url) {
    const response = await fetch(`/api/parse?url=${encodeURIComponent(url)}`);
    if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || "Server parsing failed");
    }
    return await response.json();
}

// Load Playlist Click
document.getElementById('btn-load-playlist').addEventListener('click', loadPlaylist);

async function loadPlaylist() {
    const url = document.getElementById('et-playlist-url').value.trim();
    if (!url) {
        showError("Please paste a playlist URL into the box above first.");
        return;
    }
    
    elInputSection.style.display = 'none';
    elPbLoading.style.display = 'block';
    
    // Clear previous tracks from UI immediately
    elRvTracks.innerHTML = '';
    document.getElementById('tv-playlist-name').innerText = '';
    document.getElementById('tv-playlist-desc').innerText = '';
    
    let loadedPlaylist = null;
    
    // 1. Try server-side parse first (which is 100% reliable)
    try {
        if (window.location.protocol !== "file:") {
            loadedPlaylist = await parsePlaylistOnServer(url);
        }
    } catch (e) {
        console.warn("Server parse failed, falling back to client-side parsing...", e);
    }
    
    // 2. Fallback to client-side parsing if server parse failed/not available
    if (!loadedPlaylist) {
        try {
            if (url.includes("PL_demo_sql")) {
                // Force demo preset SQL
                const tracks = generateSimulatedPlaylist();
                loadedPlaylist = {
                    title: "Oracle SQL & PL/SQL Masterclass (Sudhakar)",
                    description: "Simulating YouTube Playlist parsing. Selected items will download actual sample video/audio files from standard public CDNs for real end-to-end testing.",
                    tracks: tracks
                };
            } else if (url.includes("youtube.com/playlist") || url.includes("youtu.be/playlist") || url.includes("youtube.com/list")) {
                loadedPlaylist = await parseYoutubePlaylist(url);
            } else if (url.includes("youtube.com/watch") || url.includes("youtu.be/")) {
                loadedPlaylist = await parseYoutubeVideo(url);
            } else if (url.endsWith(".m3u") || url.includes(".m3u?")) {
                loadedPlaylist = await parseM3UPlaylist(url);
            } else if (url.startsWith("http://") || url.startsWith("https://")) {
                // Treat other direct HTTP links as a single video track
                loadedPlaylist = generateSingleTrackPlaylist(url);
            }
        } catch (e) {
            console.error("Client-side fallback loading error: ", e);
        }
    }
    
    // 3. Fallback check
    if (!loadedPlaylist) {
        if (url.includes("PL_demo_sql") || url.includes("youtube.com/playlist?list=PL_demo_sql") || url === "https://youtube.com/playlist?list=PL_demo_sql") {
            const tracks = generateSimulatedPlaylist();
            loadedPlaylist = {
                title: "Oracle SQL & PL/SQL Masterclass (Sudhakar)",
                description: "Simulating YouTube Playlist parsing. Selected items will download actual sample video/audio files from standard public CDNs for real end-to-end testing.",
                tracks: tracks
            };
        } else {
            // Custom link parsing failed completely
            elPbLoading.style.display = 'none';
            elInputSection.style.display = 'flex';
            elBtnBack.style.display = 'none';
            elHeaderTitle.innerText = "Video Downloader";
            
            let errMsg = "Failed to load playlist details.\n\n";
            if (window.location.protocol === "file:") {
                errMsg += "REASON: You are running index.html directly via file://.\nBrowser security policies block network requests from local files, causing the YouTube parser to fail.\n\nHOW TO FIX: Please double-click 'run-desktop-version.bat' in your DB folder. It will start a local server and open http://localhost:8000/DesktopDownloader/index.html, enabling full playlist parsing.";
            } else {
                errMsg += "REASON: The link provided might be private, invalid, or there is a temporary network problem. Please check your network and verify the URL is public.";
            }
            alert(errMsg);
            return;
        }
    }
    
    elPbLoading.style.display = 'none';
    elPlaylistDetails.style.display = 'block';
    elBtnBack.style.display = 'block';
    elHeaderTitle.innerText = "PlayList Detail";
    
    document.getElementById('tv-playlist-name').innerText = loadedPlaylist.title;
    document.getElementById('tv-playlist-desc').innerText = loadedPlaylist.description;
    
    tracksList = loadedPlaylist.tracks;
    renderTracks();
    
    const elEmptyState = document.querySelector('.empty-state');
    if (elEmptyState) elEmptyState.style.display = 'none';
    if (elListControls) elListControls.style.display = 'flex';
    
    // Initial Range Setup
    document.getElementById('et-range-start').value = 1;
    document.getElementById('et-range-end').value = tracksList.length;
    
    updateSelectionStats();
}

function renderTracks() {
    elRvTracks.innerHTML = '';
    tracksList.forEach((track, index) => {
        const item = document.createElement('div');
        item.className = `track-item ${track.isSelected ? 'selected' : ''}`;
        item.id = `item-${track.id}`;
        
        const sizeMb = (track.sizeBytes / (1024 * 1024)).toFixed(1);
        const viewsCount = (Math.abs(track.title.hashCode() % 100) / 10 + 1).toFixed(1);
        
        item.innerHTML = `
            <div class="track-thumbnail-wrapper">
                <img class="track-thumb" src="${track.thumbnail}" alt="thumbnail">
                <div class="track-duration">${track.duration}</div>
            </div>
            <div class="track-info">
                <div class="track-title">${track.title}</div>
                <div class="track-meta" id="meta-${track.id}">${viewsCount}K views • ${sizeMb} MB</div>
                <div class="track-status-badge" id="badge-${track.id}"></div>
            </div>
            <div class="track-checkbox" id="check-${track.id}"></div>
        `;
        
        item.addEventListener('click', (e) => {
            toggleTrackSelection(index);
        });
        
        elRvTracks.appendChild(item);
    });
}

// Deterministic title hashcode helper
String.prototype.hashCode = function() {
    let hash = 0;
    for (let i = 0; i < this.length; i++) {
        hash = this.charCodeAt(i) + ((hash << 5) - hash);
    }
    return hash;
};

function toggleTrackSelection(index) {
    if (isDownloading) return;
    tracksList[index].isSelected = !tracksList[index].isSelected;
    const itemEl = document.getElementById(`item-${tracksList[index].id}`);
    if (tracksList[index].isSelected) {
        itemEl.classList.add('selected');
    } else {
        itemEl.classList.remove('selected');
    }
    updateSelectionStats();
}

function updateSelectionStats() {
    const selectedCount = tracksList.filter(t => t.isSelected).length;
    document.getElementById('tv-selection-ratio').innerText = `${selectedCount} items selected`;
    document.getElementById('tv-videos-count').innerText = `${tracksList.length} videos`;
    
    if (elCbSelectAll) {
        elCbSelectAll.checked = (selectedCount === tracksList.length && tracksList.length > 0);
    }
}

if (elCbSelectAll) {
    elCbSelectAll.addEventListener('change', (e) => {
        if (isDownloading) {
            e.preventDefault();
            return;
        }
        const selectAll = e.target.checked;
        
        tracksList.forEach((track) => {
            track.isSelected = selectAll;
            const itemEl = document.getElementById(`item-${track.id}`);
            if (selectAll) {
                itemEl.classList.add('selected');
            } else {
                itemEl.classList.remove('selected');
            }
        });
        updateSelectionStats();
    });
}

// Range Selection
document.getElementById('btn-select-range').addEventListener('click', () => {
    const startVal = parseInt(document.getElementById('et-range-start').value) || 1;
    const endVal = parseInt(document.getElementById('et-range-end').value) || tracksList.length;
    
    tracksList.forEach((track, i) => {
        const pos = i + 1;
        if (pos >= startVal && pos <= endVal) {
            track.isSelected = true;
            document.getElementById(`item-${track.id}`).classList.add('selected');
        }
    });
    updateSelectionStats();
});

document.getElementById('btn-clear-range').addEventListener('click', () => {
    const startVal = parseInt(document.getElementById('et-range-start').value) || 1;
    const endVal = parseInt(document.getElementById('et-range-end').value) || tracksList.length;
    
    tracksList.forEach((track, i) => {
        const pos = i + 1;
        if (pos >= startVal && pos <= endVal) {
            track.isSelected = false;
            document.getElementById(`item-${track.id}`).classList.remove('selected');
        }
    });
    updateSelectionStats();
});

// Open Dialog Options
document.getElementById('btn-download-playlist').addEventListener('click', openOptionsDialog);
document.getElementById('btn-selection-done').addEventListener('click', openOptionsDialog);

function openOptionsDialog() {
    const selectedCount = tracksList.filter(t => t.isSelected).length;
    if (selectedCount === 0) {
        alert("Please select at least 1 video to download");
        return;
    }
    
    document.getElementById('dialog-items-selected').innerText = `${selectedCount} items selected`;
    elDialogOptions.style.display = 'flex';
}

// Dismiss dialog and start downloads
document.getElementById('btn-dialog-download').addEventListener('click', () => {
    elDialogOptions.style.display = 'none';
    
    // Show floating downloads window
    if (elFloatingDownloads) {
        elFloatingDownloads.style.display = 'flex';
        elFloatingContentArea.style.display = 'block';
        elBtnMinimizeDownloads.innerText = '_';
    }
    
    downloadSubtitles = elSwitchSubtitles.checked;
    
    startDownloads();
});

// Download Process
function startDownloads() {
    isDownloading = true;
    isPaused = false;
    
    const pendingTracks = tracksList.filter(t => t.isSelected && t.status !== 'COMPLETED');
    pendingTracks.forEach(t => {
        t.status = 'QUEUED';
        updateTrackUIStatus(t);
    });
    
    if (window.location.protocol !== "file:") {
        startServerDownloads(pendingTracks);
    } else {
        runDownloadQueue();
    }
}

async function startServerDownloads(pendingTracks) {
    try {
        await fetch('/api/download', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                tracks: pendingTracks,
                quality: document.querySelector('input[name="quality"]:checked').value,
                subtitles: document.getElementById('switch-dialog-subtitles').checked
            })
        });
        
        pollServerProgress();
    } catch (e) {
        console.error("Failed to start server downloads, starting local simulation", e);
        runDownloadQueue();
    }
}

let serverProgressInterval = null;
function pollServerProgress() {
    if (serverProgressInterval) clearInterval(serverProgressInterval);
    
    serverProgressInterval = setInterval(async () => {
        if (isPaused) return;
        
        try {
            const response = await fetch('/api/progress');
            if (!response.ok) return;
            
            const progressMap = await response.json();
            let allCompleted = true;
            
            tracksList.forEach(t => {
                const statusInfo = progressMap[t.id];
                if (statusInfo) {
                    const oldStatus = t.status;
                    t.status = statusInfo.status;
                    t.progress = statusInfo.progress;
                    
                    // Files are now saved directly to the PC's Downloads folder, no need to trigger manual browser download
                    if (t.status === 'COMPLETED' && oldStatus !== 'COMPLETED') {
                        console.log(`Download for ${t.title} completed successfully and saved to Downloads folder.`);
                    }
                    
                    if (t.status === 'FILE_EXISTS' && oldStatus !== 'FILE_EXISTS') {
                        showFileExistsPrompt(t.id, t.title);
                    }
                    
                    if (t.status !== 'COMPLETED' && t.status !== 'FAILED' && t.status !== 'FILE_EXISTS') {
                        allCompleted = false;
                    }
                    
                    updateTrackUIStatus(t);
                }
            });
            
            renderActiveDownloads(progressMap);
            
            const selectedTracks = tracksList.filter(t => t.isSelected);
            if (selectedTracks.length > 0 && selectedTracks.every(t => t.status === 'COMPLETED' || t.status === 'FAILED')) {
                clearInterval(serverProgressInterval);
                isDownloading = false;
                
                // Hide floating downloads after a few seconds
                setTimeout(() => {
                    if (elFloatingDownloads) elFloatingDownloads.style.display = 'none';
                }, 3000);
            }
        } catch (e) {
            console.error("Error polling server progress", e);
        }
    }, 500);
}

function updateTrackUIStatus(track) {
    const metaEl = document.getElementById(`meta-${track.id}`);
    const badgeEl = document.getElementById(`badge-${track.id}`);
    
    if (track.status === 'QUEUED') {
        if(metaEl) metaEl.innerText = "In Queue • Waiting...";
        if(badgeEl) badgeEl.style.display = 'none';
    } else if (track.status === 'DOWNLOADING') {
        if(metaEl) metaEl.innerText = `Downloading... ${track.progress}%`;
        if(badgeEl) {
            badgeEl.style.display = 'inline-block';
            badgeEl.className = 'track-status-badge status-downloading';
            badgeEl.innerText = 'DOWNLOADING';
        }
    } else if (track.status === 'COMPLETED') {
        if(metaEl) metaEl.innerText = "Downloaded successfully";
        if(badgeEl) {
            badgeEl.style.display = 'inline-block';
            badgeEl.className = 'track-status-badge status-completed';
            badgeEl.innerText = 'DONE';
        }
    } else if (track.status === 'PAUSED') {
        if(metaEl) metaEl.innerText = `Paused • ${track.progress}%`;
    } else if (track.status === 'FILE_EXISTS') {
        if(metaEl) metaEl.innerText = "Waiting for user resolution...";
        if(badgeEl) {
            badgeEl.style.display = 'inline-block';
            badgeEl.className = 'track-status-badge status-failed';
            badgeEl.innerText = 'EXISTS';
            badgeEl.style.backgroundColor = 'var(--secondary)';
        }
    } else if (track.status === 'FAILED') {
        if(metaEl) metaEl.innerText = "Error";
        if(badgeEl) {
            badgeEl.style.display = 'inline-block';
            badgeEl.className = 'track-status-badge status-failed';
            badgeEl.innerText = 'FAILED';
        }
    }
}

function renderActiveDownloads(progressData) {
    if (!elActiveDownloadsList) return;
    elActiveDownloadsList.innerHTML = '';
    
    // Sort so downloading items are on top
    const downloadingTracks = tracksList.filter(t => t.isSelected && t.status !== 'COMPLETED');
    
    downloadingTracks.forEach(track => {
        const dItem = document.createElement('div');
        dItem.className = 'active-download-item';
        
        let statusColor = 'var(--text-secondary)';
        let pWidth = track.progress || 0;
        
        if (track.status === 'DOWNLOADING') statusColor = 'var(--primary)';
        if (track.status === 'FAILED') statusColor = 'var(--error)';
        
        dItem.innerHTML = `
            <img src="${track.thumbnail}" alt="thumb">
            <div class="active-download-info">
                <div class="active-download-title">${track.title}</div>
                <div class="active-download-meta" style="color: ${statusColor}">${track.status === 'QUEUED' ? 'Waiting...' : track.status + ' - ' + pWidth + '%'}</div>
                <div class="active-download-pb-container">
                    <div class="active-download-pb-fill" style="width: ${pWidth}%; background-color: ${statusColor}"></div>
                </div>
            </div>
        `;
        elActiveDownloadsList.appendChild(dItem);
    });
}

// Active Queue execution using 3 parallel slots
function runDownloadQueue() {
    if (isPaused) return;
    
    const activeRunning = tracksList.filter(t => t.status === 'DOWNLOADING').length;
    const slotsAvailable = 3 - activeRunning;
    
    if (slotsAvailable <= 0) return;
    
    const queuedTracks = tracksList.filter(t => t.status === 'QUEUED');
    for (let i = 0; i < Math.min(slotsAvailable, queuedTracks.length); i++) {
        downloadSingleTrack(queuedTracks[i]);
    }
}

function getLocalFilename(day, isPart1 = false, isPart2 = false) {
    const base = "ORACLE_SQL___PL_SQL___9_00_AM_IST_by_Mr__Sudhakar_L720P_HD(0)";
    if (day === 12) {
        if (isPart1) return `Day_12_#PART___1_${base}`;
        if (isPart2) return `Day_12_#PART___2_${base}`;
    }
    return `Day_${day}_${base}`;
}

function triggerActualDownload(url, filename) {
    try {
        const a = document.createElement("a");
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    } catch (e) {
        console.error("Failed to trigger download for " + url, e);
    }
}

async function downloadSingleTrack(track) {
    track.status = 'DOWNLOADING';
    track.progress = 0;
    updateTrackUIStatus(track);
    
    // Parse day and part details to locate actual file
    const dayMatch = track.title.match(/Day (\d+)/);
    const day = dayMatch ? parseInt(dayMatch[1]) : 9;
    const isPart1 = track.title.includes("#PART 1");
    const isPart2 = track.title.includes("#PART 2");
    
    const baseName = getLocalFilename(day, isPart1, isPart2);
    const videoRelativeUrl = `../BD/${baseName}.mp4`;
    const subtitleRelativeUrl = `../BD/cc/${baseName}.cc.en.ttml`;

    // Simulate high-speed local stream buffer
    let mockProgress = 0;
    const interval = setInterval(() => {
        if (isPaused) {
            clearInterval(interval);
            track.status = 'PAUSED';
            updateTrackUIStatus(track);
            return;
        }
        
        mockProgress += 10;
        if (mockProgress >= 100) {
            clearInterval(interval);
            track.status = 'COMPLETED';
            track.progress = 100;
            updateTrackUIStatus(track);
            
            // Trigger actual browser download of full local video file from BD/
            triggerActualDownload(videoRelativeUrl, `${baseName}.mp4`);
            
            // Trigger subtitle download if enabled
            if (downloadSubtitles) {
                triggerActualDownload(subtitleRelativeUrl, `${baseName}.cc.en.ttml`);
            }
            
            activeWorkers = activeWorkers.filter(w => w.trackId !== track.id);
            runDownloadQueue();
            checkQueueCompletion();
        } else {
            track.progress = mockProgress;
            updateTrackUIStatus(track);
        }
    }, 150);
}

function checkQueueCompletion() {
    const selectedTracks = tracksList.filter(t => t.isSelected);
    
    // Update active downloads window explicitly on local sim end
    renderActiveDownloads();
    
    if (selectedTracks.length > 0 && selectedTracks.every(t => t.status === 'COMPLETED' || t.status === 'FAILED')) {
        isDownloading = false;
        
        // Hide floating downloads after a few seconds
        setTimeout(() => {
            if (elFloatingDownloads) elFloatingDownloads.style.display = 'none';
        }, 3000);
        
        alert("Success! Local download simulation finished.");
    }
}

// Show Downloads Top-Right button click
elBtnShowDownloads.addEventListener('click', () => {
    const selectedTracks = tracksList.filter(t => t.isSelected);
    if (selectedTracks.length > 0) {
        elInputSection.style.display = 'none';
        elPlaylistDetails.style.display = 'block';
        elBtnBack.style.display = 'block';
        elHeaderTitle.innerText = "Active Downloads";
        
        if (isDownloading && elFloatingDownloads) {
            elFloatingDownloads.style.display = 'flex';
        }
    } else {
        alert("No active downloads in progress.");
    }
});

if (elBtnFloatingPause) {
    elBtnFloatingPause.addEventListener('click', async () => {
        if (!isPaused) {
            isPaused = true;
            elBtnFloatingPause.innerText = 'Resume';
            if (window.location.protocol !== "file:") {
                await fetch('/api/pause', { method: 'POST' });
            }
            tracksList.filter(t => t.status === 'DOWNLOADING' || t.status === 'QUEUED').forEach(t => t.status = 'PAUSED');
            renderActiveDownloads();
        } else {
            isPaused = false;
            elBtnFloatingPause.innerText = 'Pause';
            if (window.location.protocol !== "file:") {
                await fetch('/api/resume', { method: 'POST' });
                pollServerProgress();
            } else {
                runDownloadQueue();
            }
        }
    });
}

if (elBtnFloatingCancel) {
    elBtnFloatingCancel.addEventListener('click', async () => {
        if (confirm('Cancel all downloads?')) {
            isDownloading = false;
            isPaused = false;
            if (elBtnFloatingPause) elBtnFloatingPause.innerText = 'Pause';
            
            if (window.location.protocol !== "file:") {
                await fetch('/api/cancel', { method: 'POST' });
                if (serverProgressInterval) clearInterval(serverProgressInterval);
            } else {
                activeWorkers.forEach(w => w.controller.abort());
                activeWorkers = [];
            }
            
            tracksList.filter(t => t.status !== 'COMPLETED').forEach(t => {
                t.status = 'FAILED';
                t.progress = 0;
            });
            renderActiveDownloads();
            
            setTimeout(() => {
                if (elFloatingDownloads) elFloatingDownloads.style.display = 'none';
            }, 2000);
        }
    });
}

// File Exists Logic
let fileExistsQueue = [];
let isShowingExistsPrompt = false;

function showFileExistsPrompt(trackId, title) {
    fileExistsQueue.push({ trackId, title });
    processFileExistsQueue();
}

function processFileExistsQueue() {
    if (isShowingExistsPrompt || fileExistsQueue.length === 0) return;
    
    isShowingExistsPrompt = true;
    const current = fileExistsQueue.shift();
    
    const modal = document.getElementById('dialog-file-exists');
    document.getElementById('tv-file-exists-msg').innerText = `The downloaded file for "${current.title}" already exists in the destination folder.\n\nDo you want to Replace it or Skip downloading?`;
    modal.style.display = 'flex';
    
    document.getElementById('btn-exists-skip').onclick = () => {
        modal.style.display = 'none';
        resolveFileExists(current.trackId, 'skip');
        isShowingExistsPrompt = false;
        processFileExistsQueue();
    };
    
    document.getElementById('btn-exists-replace').onclick = () => {
        modal.style.display = 'none';
        resolveFileExists(current.trackId, 'replace');
        isShowingExistsPrompt = false;
        processFileExistsQueue();
    };
}

function resolveFileExists(trackId, action) {
    fetch(`/api/resolve_exists?id=${trackId}&action=${action}`, { method: 'POST' });
}
