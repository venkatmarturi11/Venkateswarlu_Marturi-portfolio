import http.server
import socketserver
import sys
import os

if sys.stdout is None:
    sys.stdout = open(os.devnull, 'w')
if sys.stderr is None:
    sys.stderr = open(os.devnull, 'w')
import urllib.parse
import json
import os
import re
import shutil
import threading
import time

PORT = 8000
import sys
if getattr(sys, 'frozen', False):
    if hasattr(sys, '_MEIPASS'):
        DIRECTORY = sys._MEIPASS
    else:
        DIRECTORY = os.path.dirname(sys.executable)
else:
    DIRECTORY = os.path.dirname(os.path.abspath(__file__))

# Global states to track download progress
downloads_status = {}
is_paused = False

class CustomHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIRECTORY, **kwargs)

    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_GET(self):
        parsed_url = urllib.parse.urlparse(self.path)
        if parsed_url.path == '/api/parse':
            query = urllib.parse.parse_qs(parsed_url.query)
            playlist_url = query.get('url', [''])[0]
            self.handle_parse(playlist_url)
        elif parsed_url.path == '/api/progress':
            self.handle_progress()
        elif parsed_url.path == '/api/default-path':
            downloads_dir = os.path.join(os.path.expanduser('~'), 'Downloads')
            self.send_json({"path": downloads_dir})
        elif parsed_url.path == '/api/clipboard':
            try:
                import subprocess
                # Use powershell to get clipboard text since we are on Windows
                clip_text = subprocess.check_output(['powershell', '-command', 'Get-Clipboard']).decode('utf-8').strip()
                self.send_json({"text": clip_text})
            except Exception as e:
                self.send_json({"error": str(e)}, 500)
        elif parsed_url.path == '/api/download-app':
            import zipfile
            import io
            
            memory_file = io.BytesIO()
            files_to_zip = ['server.py', 'desktop.py', 'app.js', 'index.html', 'styles.css', 'requirements.txt', 'run-desktop-version.bat']
            
            with zipfile.ZipFile(memory_file, 'w', zipfile.ZIP_DEFLATED) as zf:
                for file_name in files_to_zip:
                    file_path = os.path.join(DIRECTORY, file_name)
                    if os.path.exists(file_path):
                        zf.write(file_path, file_name)
            
            memory_file.seek(0)
            
            self.send_response(200)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition', 'attachment; filename="DesktopDownloader_Portable.zip"')
            self.send_header('Content-Length', str(len(memory_file.getvalue())))
            self.end_headers()
            self.wfile.write(memory_file.getvalue())
        elif parsed_url.path.startswith('/api/stream/'):
            video_name = urllib.parse.unquote(parsed_url.path.split('/api/stream/')[1])
            bd_dir = os.path.abspath(os.path.join(DIRECTORY, "..", "BD"))
            video_path = os.path.join(bd_dir, video_name)
            if os.path.exists(video_path):
                try:
                    f = open(video_path, 'rb')
                except OSError:
                    self.send_error(404, "File not found")
                    return
                try:
                    fs = os.fstat(f.fileno())
                    self.send_response(200)
                    self.send_header("Content-type", "video/mp4")
                    self.send_header("Content-Length", str(fs.st_size))
                    self.end_headers()
                    shutil.copyfileobj(f, self.wfile)
                except Exception as e:
                    print(f"Error streaming file: {e}")
                finally:
                    f.close()
            else:
                self.send_error(404, "File not found")
        elif parsed_url.path == '/api/download_file':
            query = urllib.parse.parse_qs(parsed_url.query)
            track_id = query.get('id', [''])[0]
            if track_id in downloads_status and 'filepath' in downloads_status[track_id]:
                filepath = downloads_status[track_id]['filepath']
                if filepath and os.path.exists(filepath):
                    filename = os.path.basename(filepath)
                    self.send_response(200)
                    self.send_header('Content-Type', 'application/octet-stream')
                    self.send_header('Content-Disposition', f'attachment; filename="{urllib.parse.quote(filename)}"')
                    self.send_header('Content-Length', str(os.path.getsize(filepath)))
                    self.end_headers()
                    with open(filepath, 'rb') as f:
                        shutil.copyfileobj(f, self.wfile)
                    return
            self.send_error(404, "File not found or not finished")
        else:
            super().do_GET()

    def do_POST(self):
        parsed_url = urllib.parse.urlparse(self.path)
        if parsed_url.path == '/api/download':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            data = json.loads(post_data.decode('utf-8'))
            self.handle_download(data)
        elif parsed_url.path == '/api/pause':
            global is_paused
            is_paused = True
            self.send_json({"status": "paused"})
        elif parsed_url.path == '/api/resume':
            is_paused = False
            self.send_json({"status": "resumed"})
        elif parsed_url.path == '/api/cancel':
            is_paused = False
            downloads_status.clear()
            self.send_json({"status": "cancelled"})
        elif parsed_url.path == '/api/resolve_exists':
            query = urllib.parse.parse_qs(parsed_url.query)
            track_id = query.get('id', [''])[0]
            action = query.get('action', [''])[0]
            if track_id in downloads_status:
                downloads_status[track_id]['action'] = action
            self.send_json({"status": "resolved"})
        else:
            self.send_error(404, "File not found")

    def handle_parse(self, playlist_url):
        if not playlist_url:
            self.send_json({"error": "Missing URL"}, 400)
            return

        # Special local demo SQL check (or if url contains Sudhakar/PL_demo_sql)
        if "PL_demo_sql" in playlist_url or "sudhakar" in playlist_url.lower():
            self.send_demo_playlist()
            return

        try:
            yt_dlp = __import__("yt_dlp")
            ydl_opts = {
                'extract_flat': True,
                'skip_download': True,
                'quiet': True,
                'no_warnings': True,
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(playlist_url, download=False)
                
                is_playlist = 'entries' in info and info['entries'] is not None
                title = info.get('title', 'YouTube Video') or 'YouTube Video'
                description = info.get('description', '') or 'Imported URL'
                
                tracks = []
                if is_playlist:
                    # Convert generator to list to avoid iteration issues
                    entries_list = list(info['entries'])
                    for index, entry in enumerate(entries_list):
                        try:
                            if not entry: continue
                            duration_sec = entry.get('duration')
                            if duration_sec is None or not isinstance(duration_sec, (int, float)):
                                duration_sec = 300
                            duration_sec = int(duration_sec)
                            duration_str = self.format_duration(duration_sec)
                            
                            video_id = entry.get('id', f"track-{index}")
                            video_title = entry.get('title', f"Video #{index+1}") or f"Video #{index+1}"
                            thumbnail = entry.get('thumbnail') or f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"
                            
                            tracks.append({
                                "id": video_id,
                                "title": video_title,
                                "duration": duration_str,
                                "sizeBytes": duration_sec * 250000,
                                "downloadUrl": f"https://www.youtube.com/watch?v={video_id}",
                                "thumbnail": thumbnail,
                                "isSelected": True,
                                "status": "PENDING",
                                "progress": 0
                            })
                        except Exception as entry_err:
                            print(f"Skipping entry {index}: {entry_err}")
                            continue
                else:
                    duration_sec = info.get('duration')
                    if duration_sec is None or not isinstance(duration_sec, (int, float)):
                        duration_sec = 300
                    duration_sec = int(duration_sec)
                    duration_str = self.format_duration(duration_sec)
                    video_id = info.get('id', 'video-1')
                    thumbnail = info.get('thumbnail') or f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"
                    
                    tracks.append({
                        "id": video_id,
                        "title": title,
                        "duration": duration_str,
                        "sizeBytes": duration_sec * 250000,
                        "downloadUrl": playlist_url,
                        "thumbnail": thumbnail,
                        "isSelected": True,
                        "status": "PENDING",
                        "progress": 0
                    })

                self.send_json({
                    "title": title,
                    "description": description,
                    "tracks": tracks
                })
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.send_json({"error": str(e)}, 500)

    def handle_download(self, data):
        tracks = data.get('tracks', [])
        quality = data.get('quality', 'v_720p')
        subtitles = data.get('subtitles', True)

        save_path = os.path.join(os.path.expanduser('~'), 'Downloads')
        os.makedirs(save_path, exist_ok=True)

        print(f"[Download] Saving to folder: {save_path}")
        threading.Thread(target=run_yt_dlp_downloads, args=(tracks, save_path, quality, subtitles)).start()
        self.send_json({"status": "started"})

    def handle_progress(self):
        self.send_json(downloads_status)

    def send_json(self, data, status_code=200):
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps(data).encode('utf-8'))

    def format_duration(self, seconds):
        hours = seconds // 3600
        minutes = (seconds % 3600) // 60
        secs = seconds % 60
        if hours > 0:
            return f"{hours}:{minutes:02d}:{secs:02d}"
        else:
            return f"{minutes}:{secs:02d}"

    def send_demo_playlist(self):
        tracks = []
        base_title = "ORACLE SQL & PL/SQL - 9:00 AM IST by Mr. Sudhakar"
        demo_thumb = "https://i.ytimg.com/vi/dQw4w9WgXcQ/hqdefault.jpg"
        for day in range(9, 69):
            if day == 12:
                tracks.append({
                    "id": "track-12-p1",
                    "title": f"Day 12 #PART 1 - {base_title}",
                    "duration": "1:15:30",
                    "sizeBytes": 209900000,
                    "downloadUrl": "demo-local",
                    "thumbnail": demo_thumb,
                    "isSelected": True,
                    "status": "PENDING",
                    "progress": 0
                })
                tracks.append({
                    "id": "track-12-p2",
                    "title": f"Day 12 #PART 2 - {base_title}",
                    "duration": "1:08:45",
                    "sizeBytes": 184700000,
                    "downloadUrl": "demo-local",
                    "thumbnail": demo_thumb,
                    "isSelected": True,
                    "status": "PENDING",
                    "progress": 0
                })
            else:
                size = 156300000 if day == 9 else (200800000 if day == 10 else 199500000)
                dur = "1:02:15" if day == 9 else ("1:18:40" if day == 10 else "1:16:10")
                tracks.append({
                    "id": f"track-{day}",
                    "title": f"Day {day} - {base_title}",
                    "duration": dur,
                    "sizeBytes": size,
                    "downloadUrl": "demo-local",
                    "thumbnail": demo_thumb,
                    "isSelected": True,
                    "status": "PENDING",
                    "progress": 0
                })
        self.send_json({
            "title": "Oracle SQL & PL/SQL Masterclass (Sudhakar)",
            "description": "Simulating YouTube Playlist parsing. Selected items will download actual sample video/audio files from standard public CDNs for real end-to-end testing.",
            "tracks": tracks
        })

def run_yt_dlp_downloads(tracks, save_path, quality, subtitles):
    yt_dlp = __import__("yt_dlp")
    global is_paused
    is_paused = False
    
    for t in tracks:
        downloads_status[t['id']] = {"status": "QUEUED", "progress": 0, "speed": "0.0 MB/s"}
        
    for t in tracks:
        while is_paused:
            time.sleep(0.5)
            
        track_id = t['id']
        url = t['downloadUrl']
        title = t['title']
        
        if url == "demo-local":
            downloads_status[track_id] = {"status": "DOWNLOADING", "progress": 0, "speed": "Local Copy"}
            copy_local_sql_demo(track_id, title, save_path, subtitles)
            continue
            
        downloads_status[track_id] = {"status": "DOWNLOADING", "progress": 0, "speed": "Connecting..."}
        
        def yt_dlp_hook(d):
            if is_paused:
                downloads_status[track_id] = {"status": "PAUSED", "progress": downloads_status[track_id]["progress"], "speed": "Paused"}
                return

            if d['status'] == 'downloading':
                downloaded = d.get('downloaded_bytes', 0)
                total = d.get('total_bytes', 0) or d.get('total_bytes_estimate', 1)
                percent = int(downloaded * 100 / total)
                speed_bytes = d.get('speed', 0) or 0
                speed_mb = speed_bytes / (1024 * 1024)
                
                downloads_status[track_id] = {
                    "status": "DOWNLOADING",
                    "progress": percent,
                    "speed": f"{speed_mb:.1f} MB/s"
                }
            elif d['status'] == 'finished':
                downloads_status[track_id] = {
                    "status": "COMPLETED",
                    "progress": 100,
                    "speed": "Done",
                    "filepath": d.get('filename')
                }

        ydl_opts = {
            'outtmpl': os.path.join(save_path, '%(title)s.%(ext)s'),
            'progress_hooks': [yt_dlp_hook],
            'quiet': True,
            'no_warnings': True,
            'overwrites': True,
        }
        
        try:
            imageio_ffmpeg = __import__("imageio_ffmpeg")
            ydl_opts['ffmpeg_location'] = imageio_ffmpeg.get_ffmpeg_exe()
        except ImportError:
            pass
        
        if quality.startswith('m_'):
            # Audio-only: extract to mp3 using ffmpeg postprocessor
            ydl_opts['format'] = 'bestaudio/best'
            ydl_opts['postprocessors'] = [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': 'mp3',
                'preferredquality': '192',
            }]
        elif quality == 'v_highest':
            # Highest available resolution (requires ffmpeg for merging)
            ydl_opts['format'] = 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best'
        else:
            height = quality.split('_')[1].replace('p', '')
            # Use single pre-merged format (no ffmpeg needed for merging)
            ydl_opts['format'] = f'best[height<={height}][ext=mp4]/best[height<={height}]/best[ext=mp4]/best'
            
        if subtitles:
            ydl_opts['writesubtitles'] = True
            ydl_opts['subtitleslangs'] = ['en']
            
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                expected_filename = ydl.prepare_filename(info)
                
            if quality.startswith('m_'):
                expected_filename = os.path.splitext(expected_filename)[0] + '.mp3'
                
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
        except Exception as e:
            downloads_status[track_id] = {
                "status": "FAILED",
                "progress": 0,
                "speed": "Error"
            }

def copy_local_sql_demo(track_id, title, save_path, subtitles):
    try:
        import shutil
        day_match = re.search(r'Day (\d+)', title)
        day = int(day_match.group(1)) if day_match else 9
        is_part1 = "PART 1" in title
        is_part2 = "PART 2" in title
        
        base = "ORACLE_SQL___PL_SQL___9_00_AM_IST_by_Mr__Sudhakar_L720P_HD(0)"
        filename = f"Day_{day}_{base}"
        if day == 12:
            if is_part1: filename = f"Day_12_#PART___1_{base}"
            elif is_part2: filename = f"Day_12_#PART___2_{base}"
            
        bd_dir = os.path.abspath(os.path.join(DIRECTORY, "..", "BD"))
        src_video = os.path.join(bd_dir, f"{filename}.mp4")
        dst_video = os.path.join(save_path, f"{filename}.mp4")
        
        for progress in range(10, 101, 20):
            downloads_status[track_id] = {
                "status": "DOWNLOADING",
                "progress": progress,
                "speed": "Local Copy"
            }
            time.sleep(0.05)
            
        if os.path.exists(src_video):
            shutil.copy2(src_video, dst_video)
            if subtitles:
                src_sub = os.path.join(bd_dir, "cc", f"{filename}.cc.en.ttml")
                dst_sub = os.path.join(save_path, f"{filename}.cc.en.ttml")
                if os.path.exists(src_sub):
                    shutil.copy2(src_sub, dst_sub)
                    
            downloads_status[track_id] = {
                "status": "COMPLETED",
                "progress": 100,
                "speed": "Saved"
            }
        else:
            downloads_status[track_id] = {
                "status": "FAILED",
                "progress": 0,
                "speed": "Not Found"
            }
    except Exception as e:
        downloads_status[track_id] = {
            "status": "FAILED",
            "progress": 0,
            "speed": str(e)
        }

def start_server(httpd):
    print(f"Serving local downloader API at port {PORT}")
    try:
        httpd.serve_forever()
    except:
        pass

if __name__ == '__main__':
    handler = CustomHTTPRequestHandler
    socketserver.TCPServer.allow_reuse_address = True
    
    port = int(os.environ.get("PORT", PORT))
    
    with socketserver.TCPServer(("0.0.0.0", port), handler) as httpd:
        print(f"Serving at http://0.0.0.0:{port}")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nShutting down server.")
