import sys
import threading
import socket
import socketserver
from PyQt5.QtWidgets import QApplication, QMainWindow
from PyQt5.QtWebEngineWidgets import QWebEngineView, QWebEnginePage
from PyQt5.QtCore import QUrl
import server # Import the server logic

# Allow socket reuse
socketserver.TCPServer.allow_reuse_address = True

# Find a free port dynamically
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind(('127.0.0.1', 0))
    PORT = s.getsockname()[1]

def start_server(httpd):
    print(f"Serving local downloader API at port {PORT}")
    try:
        httpd.serve_forever()
    except:
        pass

if __name__ == '__main__':
    # Start background server
    handler = server.CustomHTTPRequestHandler
    httpd = socketserver.TCPServer(("127.0.0.1", PORT), handler)
    
    server_thread = threading.Thread(target=start_server, args=(httpd,), daemon=True)
    server_thread.start()

    # Start PyQt5 App
    app = QApplication(sys.argv)
    window = QMainWindow()
    window.setWindowTitle("Playlist Downloader (Native Desktop)")
    window.resize(1366, 768)
    
    browser = QWebEngineView()
    
    # Auto-grant permissions (e.g. clipboard)
    def on_feature_permission_requested(origin, feature):
        browser.page().setFeaturePermission(origin, feature, QWebEnginePage.PermissionGrantedByUser)
        
    browser.page().featurePermissionRequested.connect(on_feature_permission_requested)
    
    # Load frontend
    browser.setUrl(QUrl(f"http://127.0.0.1:{PORT}/index.html"))
    window.setCentralWidget(browser)
    
    window.show()
    sys.exit(app.exec_())
