@echo off
title Playlist Downloader
echo ============================================
echo      Playlist Downloader Launcher
echo ============================================
echo.

echo Starting native desktop application...
cd /d "%~dp0"
python desktop.py
